import dbPromise from '../models/db.js';
import { v4 as uuidv4 } from 'uuid';

export const createAccount = async ({ email, name, website }) => {
    if (!email || !name) {
        throw { statusCode: 400, message: 'Email and name are required fields.' };
    }

    const id = uuidv4();
    const app_secret = uuidv4();

    const db = await dbPromise;
    await db.run(
        'INSERT INTO accounts (id, email, name, website, app_secret) VALUES (?, ?, ?, ?, ?)',
        [id, email, name, website, app_secret]
    );

    return { id, email, name, website, app_secret };
};

export const getAccount = async (id) => {
    const db = await dbPromise;
    const account = await db.get('SELECT * FROM accounts WHERE id = ?', [id]);

    if (!account) {
        throw { statusCode: 404, message: 'Account not found.' };
    }
    return account;
};

export const updateAccount = async (id, { email, name, website }) => {
    if (!email || !name) {
        throw { statusCode: 400, message: 'Email and name are required to update the account.' };
    }
    const db = await dbPromise;
    const result = await db.run(
        'UPDATE accounts SET email = ?, name = ?, website = ? WHERE id = ?',
        [email, name, website, id]
    );

    if (result.changes === 0) {
        throw { statusCode: 404, message: 'Account not found.' };
    }
};

export const deleteAccount = async (id) => {
    const db = await dbPromise;
    const result = await db.run('DELETE FROM accounts WHERE id = ?', [id]);

    if (result.changes === 0) {
        throw { statusCode: 404, message: 'Account not found.' };
    }
};

export const getDestinationsByAccount = async (accountId) => {
    const db = await dbPromise;
    const destinations = await db.all('SELECT * FROM destinations WHERE account_id = ?', [accountId]);
    return destinations;
};
