const dbPromise = require('../models/db');
const { v4: uuidv4 } = require('uuid');

exports.createDestination = async ({ account_id, url, method, headers }) => {
    const id = uuidv4();

    const db = await dbPromise;
    await db.run(
        'INSERT INTO destinations (id, account_id, url, method, headers) VALUES (?, ?, ?, ?, ?)',
        [id, account_id, url, method.toUpperCase(), JSON.stringify(headers)]
    );

    return id;
};

exports.updateDestination = async (id, { url, method, headers }) => {
    const db = await dbPromise;
    const result = await db.run(
        'UPDATE destinations SET url = ?, method = ?, headers = ? WHERE id = ?',
        [url, method.toUpperCase(), JSON.stringify(headers), id]
    );

    if (result.changes === 0) {
        const error = new Error('Destination not found.');
        error.statusCode = 404;
        throw error;
    }
};

exports.getDestination = async (id) => {
    const db = await dbPromise;
    const destination = await db.get('SELECT * FROM destinations WHERE id = ?', [id]);

    if (!destination) {
        const error = new Error('Destination not found.');
        error.statusCode = 404;
        throw error;
    }

    return destination;
};

exports.deleteDestination = async (id) => {
    const db = await dbPromise;
    const result = await db.run('DELETE FROM destinations WHERE id = ?', [id]);

    if (result.changes === 0) {
        const error = new Error('Destination not found.');
        error.statusCode = 404;
        throw error;
    }
};
