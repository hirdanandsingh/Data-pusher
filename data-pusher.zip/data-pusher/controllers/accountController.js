const accountService = require('../services/accountService');

exports.createAccount = async (req, res) => {
    try {
        const data = await accountService.createAccount(req.body);
        res.status(201).json({
            status: 'success',
            statusCode: 201,
            message: 'Account created successfully.',
            data,
        });
    } catch (err) {
        res.status(err.statusCode || 500).json({
            status: 'error',
            statusCode: err.statusCode || 500,
            message: err.message || 'Failed to create account.',
            error: err.error || null,
        });
    }
};

exports.getAccount = async (req, res) => {
    try {
        const data = await accountService.getAccount(req.params.id);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Account retrieved successfully.',
            data,
        });
    } catch (err) {
        res.status(err.statusCode || 500).json({
            status: 'error',
            statusCode: err.statusCode || 500,
            message: err.message || 'Internal server error.',
            error: err.error || null,
        });
    }
};

exports.updateAccount = async (req, res) => {
    try {
        await accountService.updateAccount(req.params.id, req.body);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Account updated successfully.',
        });
    } catch (err) {
        res.status(err.statusCode || 500).json({
            status: 'error',
            statusCode: err.statusCode || 500,
            message: err.message || 'Failed to update account.',
            error: err.error || null,
        });
    }
};

exports.deleteAccount = async (req, res) => {
    try {
        await accountService.deleteAccount(req.params.id);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Account deleted successfully.',
        });
    } catch (err) {
        res.status(err.statusCode || 500).json({
            status: 'error',
            statusCode: err.statusCode || 500,
            message: err.message || 'Failed to delete account.',
            error: err.error || null,
        });
    }
};

exports.getDestinationsByAccount = async (req, res) => {
    try {
        const data = await accountService.getDestinationsByAccount(req.params.id);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Destinations retrieved successfully.',
            data,
        });
    } catch (err) {
        res.status(err.statusCode || 500).json({
            status: 'error',
            statusCode: err.statusCode || 500,
            message: err.message || 'Failed to retrieve destinations.',
            error: err.error || null,
        });
    }
};
