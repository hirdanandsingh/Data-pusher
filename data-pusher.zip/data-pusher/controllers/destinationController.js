const destinationService = require('../services/destinationService');

exports.createDestination = async (req, res, next) => {
    try {
        const headers = req.body.headers;
        const account_id = req.headers['x-account-id'];
        const url = req.headers['x-destination-url'];
        const method = req.headers['x-destination-method'];

        if (!account_id || !url || !method || !headers) {
            return res.status(400).json({
                status: 'error',
                statusCode: 400,
                message: 'x-account-id, x-destination-url, x-destination-method headers and body.headers are required.',
            });
        }

        const id = await destinationService.createDestination({ account_id, url, method, headers });

        res.status(201).json({
            status: 'success',
            statusCode: 201,
            message: 'Destination created successfully.',
            data: { id },
        });
    } catch (err) {
        next(err);
    }
};

exports.updateDestination = async (req, res, next) => {
    try {
        const headers = req.body.headers;
        const url = req.headers['x-destination-url'];
        const method = req.headers['x-destination-method'];

        if (!url || !method || !headers) {
            return res.status(400).json({
                status: 'error',
                statusCode: 400,
                message: 'x-destination-url, x-destination-method headers and body.headers are required.',
            });
        }

        await destinationService.updateDestination(req.params.id, { url, method, headers });

        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Destination updated successfully.',
        });
    } catch (err) {
        next(err);
    }
};

exports.getDestination = async (req, res, next) => {
    try {
        const destination = await destinationService.getDestination(req.params.id);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Destination retrieved successfully.',
            data: destination,
        });
    } catch (err) {
        next(err);
    }
};

exports.deleteDestination = async (req, res, next) => {
    try {
        await destinationService.deleteDestination(req.params.id);
        res.status(200).json({
            status: 'success',
            statusCode: 200,
            message: 'Destination deleted successfully.',
        });
    } catch (err) {
        next(err);
    }
};
