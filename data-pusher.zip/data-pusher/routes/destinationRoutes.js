import express from 'express';
import {
    createDestination,
    getDestination,
    updateDestination,
    deleteDestination
} from '../controllers/destinationController.js';

const router = express.Router();

router.post('/', createDestination);
router.get('/:id', getDestination);
router.put('/:id', updateDestination);
router.delete('/:id', deleteDestination);

export default router;
