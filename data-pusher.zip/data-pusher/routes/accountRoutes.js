import express from 'express';
import {
    createAccount,
    getAccount,
    updateAccount,
    deleteAccount,
    getDestinationsByAccount
} from '../controllers/accountController';

const router = express.Router();

router.post('/', createAccount);
router.get('/:id', getAccount);
router.put('/:id', updateAccount);
router.delete('/:id', deleteAccount);
router.get('/:id/destinations', getDestinationsByAccount);

export default router;
