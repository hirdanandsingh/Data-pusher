import express from 'express';
import bodyParser from 'body-parser';
import { DB } from './models/db.js';
import accountRoutes from './routes/accountRoutes.js';
import destinationRoutes from './routes/destinationRoutes.js';
import { handleIncomingData } from './services/destinationService.js';

const app = express();
const PORT = 3000;

await DB();
app.use(bodyParser.json());

app.use('/accounts', accountRoutes);
app.use('/destinations', destinationRoutes);
app.post('/server/incoming_data', handleIncomingData);

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
