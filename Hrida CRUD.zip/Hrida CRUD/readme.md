# Nodejs Developer Assessment – Data Pusher

## Overview

This is an Express.js web application designed to receive data for an account and forward it to multiple destinations using webhook URLs.

## Modules

### 1. Account Module
Each account should include:
- `email` (mandatory & unique)
- `accountId` (unique identifier)
- `accountName` (mandatory)
- `appSecretToken` (automatically generated)
- `website` (optional)

### 2. Destination Module
Each destination is associated with an account. An account can have multiple destinations.
Each destination includes:
- `url` (mandatory)
- `httpMethod` (mandatory)
- `headers` (mandatory, multiple key-value pairs)

**Example headers:**
```json
{
  "APP_ID": "1234APPID1234",
  "APP_SECRET": "enwdj3bshwer43bjhjs9ereuinkjcnsiurew8s",
  "ACTION": "user.update",
  "Content-Type": "application/json",
  "Accept": "*"
}
