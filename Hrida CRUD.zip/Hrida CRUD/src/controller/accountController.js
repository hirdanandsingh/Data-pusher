const {
    createAccount,
    getAccount,
    updateAccount,
    deleteAccount,
    getDestinations
} = require('../service/accountService');

exports.createAccountController = async (req, res, next) => {
    try {
        const result = await createAccount(req.body);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.getAccountController = async (req, res, next) => {
    try {
        const result = await getAccount(req.params.id);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.updateAccountController = async (req, res, next) => {
    try {
        const result = await updateAccount(req.params.id, req.body);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.deleteAccountController = async (req, res, next) => {
    try {
        const result = await deleteAccount(req.params.id);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.getDestinationsController = async (req, res, next) => {
    try {
        const result = await getDestinations(req.params.id);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
  };