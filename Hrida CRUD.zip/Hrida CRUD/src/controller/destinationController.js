const {
    createDestination,
    getDestination,
    updateDestination,
    deleteDestination
} = require('../service/destinationService');

exports.createDestinationController = async (req, res, next) => {
    try {
        const result = await createDestination(req.body);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.getDestinationController = async (req, res, next) => {
    try {
        const result = await getDestination(req.params.id);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.updateDestinationController = async (req, res, next) => {
    try {
        const result = await updateDestination(req.params.id, req.body);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};

exports.deleteDestinationController = async (req, res, next) => {
    try {
        const result = await deleteDestination(req.params.id);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
  };