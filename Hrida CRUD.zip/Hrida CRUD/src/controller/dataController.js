const { handleIncomingData } = require('../service/dataService');

exports.incomingDataController = async (req, res, next) => {
    try {
        const result = await handleIncomingData(req);
        res.status(200).json(result);
    } catch (err) {
        next(err);
    }
};