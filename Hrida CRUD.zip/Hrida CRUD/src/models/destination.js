const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    return sequelize.define('Destination', {
        id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
        url: { type: DataTypes.STRING, allowNull: false },
        method: { type: DataTypes.STRING, allowNull: false },
        headers: { type: DataTypes.JSON, allowNull: false }
    });
};