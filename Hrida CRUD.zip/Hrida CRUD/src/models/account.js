const { DataTypes } = require('sequelize');
const { v4: uuidv4 } = require('uuid');

module.exports = (sequelize) => {
    return sequelize.define('Account', {
        id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
        email: { type: DataTypes.STRING, unique: true, allowNull: false },
        name: { type: DataTypes.STRING, allowNull: false },
        website: { type: DataTypes.STRING },
        secretToken: { type: DataTypes.STRING, defaultValue: () => uuidv4(), allowNull: false }
    });
};