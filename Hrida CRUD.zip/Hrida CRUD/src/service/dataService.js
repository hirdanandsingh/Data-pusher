const { Account, Destination } = require('../config/dbConfig');
const axios = require('axios');

exports.handleIncomingData = async (req) => {
    const token = req.headers['cl-x-token'];
    const data = req.body;

    if (!token) return { status: false, message: 'Un Authenticate' };
    if (typeof data !== 'object') return { status: false, message: 'Invalid Data' };

    const account = await Account.findOne({ where: { secretToken: token } });
    if (!account) return { status: false, message: 'Account not found' };

    const destinations = await Destination.findAll({ where: { AccountId: account.id } });

    for (const dest of destinations) {
        const config = {
            method: dest.method.toLowerCase(),
            url: dest.url,
            headers: dest.headers
        };
        if (dest.method.toLowerCase() === 'get') {
            config.params = data;
        } else {
            config.data = data;
        }
        try {
            await axios(config);
        } catch (err) {
            console.error(`Failed to push to ${dest.url}`, err.message);
        }
    }

    return { status: true, message: 'Data processed successfully' };
};