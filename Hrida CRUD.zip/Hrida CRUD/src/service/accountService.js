const { Account, Destination } = require('../config/dbConfig');

exports.createAccount = async (payload) => {
    return await Account.create(payload);
};

exports.getAccount = async (id) => {
    return await Account.findByPk(id);
};

exports.updateAccount = async (id, data) => {
    const account = await Account.findByPk(id);
    return await account.update(data);
};

exports.deleteAccount = async (id) => {
    const account = await Account.findByPk(id);
    await account.destroy();
    return { message: 'Account and destinations deleted.' };
};

exports.getDestinations = async (accountId) => {
    return await Destination.findAll({ where: { AccountId: accountId } });
};