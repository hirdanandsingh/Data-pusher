
const { Destination } = require('../config/dbConfig');

exports.createDestination = async (payload) => {
    return await Destination.create(payload);
};

exports.getDestination = async (id) => {
    return await Destination.findByPk(id);
};

exports.updateDestination = async (id, data) => {
    const destination = await Destination.findByPk(id);
    return await destination.update(data);
};

exports.deleteDestination = async (id) => {
    const destination = await Destination.findByPk(id);
    await destination.destroy();
    return { message: 'Destination deleted.' };
};