const express = require('express');
const router = express.Router();
const { incomingDataController } = require('../controller/dataController');

router.post('/incoming_data', incomingDataController);

module.exports = router;