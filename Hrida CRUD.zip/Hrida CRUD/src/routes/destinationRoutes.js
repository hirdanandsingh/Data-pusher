const express = require('express');
const router = express.Router();
const {
    createDestinationController,
    getDestinationController,
    updateDestinationController,
    deleteDestinationController
} = require('../controller/destinationController');

router.route('/').post(createDestinationController);
router.route('/:id')
    .get(getDestinationController)
    .put(updateDestinationController)
    .delete(deleteDestinationController);

module.exports = router;