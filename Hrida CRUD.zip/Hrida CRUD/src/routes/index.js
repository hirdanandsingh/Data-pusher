const express = require('express');
const router = express.Router();

const accountRoutes = require('./accountRoutes');
const destinationRoutes = require('./destinationRoutes');
const dataRoutes = require('./dataRoutes');

router.use('/accounts', accountRoutes);
router.use('/destinations', destinationRoutes);
router.use('/server', dataRoutes);

module.exports = router;