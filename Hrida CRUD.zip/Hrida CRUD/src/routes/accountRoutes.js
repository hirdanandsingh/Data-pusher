const express = require('express');
const router = express.Router();
const {
    createAccountController,
    getAccountController,
    updateAccountController,
    deleteAccountController,
    getDestinationsController
} = require('../controller/accountController');

router.route('/').post(createAccountController);
router.route('/:id')
    .get(getAccountController)
    .put(updateAccountController)
    .delete(deleteAccountController);
router.route('/:id/destinations').get(getDestinationsController);

module.exports = router;