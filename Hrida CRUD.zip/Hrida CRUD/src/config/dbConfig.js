const { Sequelize } = require('sequelize');
const sequelize = new Sequelize({ dialect: 'sqlite', storage: 'database.sqlite' });

const Account = require('../models/account')(sequelize);
const Destination = require('../models/destination')(sequelize);

Account.hasMany(Destination, { onDelete: 'CASCADE' });
Destination.belongsTo(Account);

module.exports = { sequelize, Account, Destination };