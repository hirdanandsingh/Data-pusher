const express = require('express');
const bodyParser = require('body-parser');
const routes = require('./src/routes/index');
const { sequelize } = require('./src/config/dbConfig');

const app = express();
app.use(bodyParser.json());
app.use('/api', routes);

const PORT = 3000;
sequelize.sync().then(() => {
    app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
});